import React, { useContext, useEffect } from 'react'
import Context from './Context'
import withSubscription from './withSubscription'
import './comp.less'

function Comp() {
    // console.log(location)
    const store = useContext(Context)
    return (
        <div className="comp">comp1111111{store.store.data}</div>
    )
}

export default withSubscription(Comp)