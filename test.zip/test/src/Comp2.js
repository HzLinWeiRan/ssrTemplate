import React, { useEffect } from 'react'
import withSubscription from './withSubscription'

// export const fetching = async function() {
//     console.log('this')
// }

function Comp2() {
    // useEffect(() => {
    //     fetching()
    // }, [])
    return (
        <div>comp2222</div>
    )
}

export default withSubscription(Comp2)