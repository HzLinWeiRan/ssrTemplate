import React, { useContext, useEffect } from 'react'
import Context from './Context'

export default function withSubscription(WrappedComponent) {
    const Comp = function ({ ...others }) {
        const store = useContext(Context)
        useEffect(() => {
            return () => {
                console.log('clear')
                store.clear()
            }
        }, [])
        return <WrappedComponent {...others} />
    }
    return Comp
}