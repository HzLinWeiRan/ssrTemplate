import React, { useEffect, useState } from 'react'
import { Route, Link, useLocation } from 'react-router-dom'
import Context from './Context'
import routes from './routes'

function App({
    rootStore = {},
}) {
    const [store, setStore] = useState(rootStore)
    // const [firstUpdate, setFirstUpdate] = useState(true);
    // const location = useLocation()

    // useEffect(() => {
    //     if (firstUpdate) {
    //         setFirstUpdate(false)
    //         return
    //     }
    //     setStore({})
    // }, [location])
    return (
        <Context.Provider value={{
            store,
            clear: () => { setStore({}) }
        }}>
            <div className="app">
                <Link to="/comp">comp1111</Link>
                <Link to="/comp2">comp222</Link>
                <div>
                    {
                        routes.map(item => <Route key={item.path} {...item} />)
                    }
                </div>
            </div>
        </Context.Provider>
    )
}

export default App