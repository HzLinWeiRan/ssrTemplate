import React from 'react'
import path from 'path'
import webpack from 'webpack'
import webpackMiddleware from 'webpack-dev-middleware-for-koa'
import webpackConfig from './webpack.config.babel'
import { renderToString } from 'react-dom/server'
import { StaticRouter } from 'react-router'
import { ChunkExtractor } from '@loadable/server'
import Handlebars from 'handlebars'
import Koa from 'koa'
import serve from 'koa-static'
import mount from 'koa-mount'
import Router from 'koa-router'
import hbs from 'koa2-hbs'
import { matchRoutes } from 'react-router-config'
import Routes from './src/routes'

const app = new Koa()
const router = Router()

app.use(hbs.middleware({
    viewPath: `${__dirname}/views`
}))

app.use(mount('/dist', serve('dist')))

if (process.env.NODE_ENV !== 'production') {
    const compiler = webpack(webpackConfig)
    const instance = webpackMiddleware(compiler, {
        logLevel: 'silent',
        publicPath: '/dist/web',
        writeToDisk(filePath) {
            return /dist\/node\//.test(filePath) || /loadable-stats/.test(filePath)
        },
    })
    app.use(
        instance
    )
    instance.waitUntilValid(() => {
        console.log('done')
        app.listen(3000)
    })
}

const nodeStats = path.resolve('./dist/node/loadable-stats.json')
const statsFile = path.resolve('./dist/web/loadable-stats.json')

router.get('(.*)', async (ctx) => {
    const routes = matchRoutes(Routes, ctx.request.url)

    console.log(routes[0])
    // console.log(routes[0].route.component.fetching)
    const nodeExtractor = new ChunkExtractor({ statsFile: nodeStats })
    const { default: App } = nodeExtractor.requireEntrypoint()

    const extractor = new ChunkExtractor({
        statsFile,
        publicPath: '/dist/web'
    })


    const context = {}
    const rootStore = {
        data: 888888
    }

    const jsx = extractor.collectChunks(
        <StaticRouter location={ctx.request.url} context={context} ><App rootStore={rootStore} /></StaticRouter>
    )
    console.log(context)
    const html = renderToString(jsx)
    // You can now collect your script tags
    const scriptTags = extractor.getScriptTags() // or extractor.getScriptElements();
    // You can also collect your "preload/prefetch" links
    const linkTags = extractor.getLinkTags() // or extractor.getLinkElements();
    // And you can even collect your style tags (if you use "mini-css-extract-plugin")
    const styleTags = extractor.getStyleTags() // or extractor.getStyleElements();
    await ctx.render('index', {
        rootStore: new Handlebars.SafeString(JSON.stringify(rootStore)),
        scriptTags: new Handlebars.SafeString(scriptTags),
        linkTags: new Handlebars.SafeString(linkTags),
        // styleTags,
        styleTags: new Handlebars.SafeString(styleTags),
        html: new Handlebars.SafeString(html),
    })
})

app.use(router.routes()).use(router.allowedMethods())

